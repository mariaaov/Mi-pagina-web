function saludame(){
  alert("esto es un saludo");
}
saludame();
